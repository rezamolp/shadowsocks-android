<?php
$bot_token = '7779481446:AAEBRXmzDPWtCEVZn-kMIGY-PCG2rEamjAI';
require __DIR__ . '/config.php';

$content = file_get_contents("php://input");
file_put_contents(__DIR__ . '/log_update.txt', $content . PHP_EOL);
$update = json_decode($content, true);

$chat_id = $update['message']['chat']['id'] ?? null;
$text = $update['message']['text'] ?? null;
$forward_from_chat = $update['message']['forward_from_chat']['id'] ?? null;
$callback_data = $update['callback_query']['data'] ?? null;
$callback_chat = $update['callback_query']['message']['chat']['id'] ?? null;
$message_id = $update['callback_query']['message']['message_id'] ?? null;

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);
$db->set_charset('utf8mb4');

function sendMessage($chat_id, $text, $reply_markup = null) {
    global $bot_token;
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) $data['reply_markup'] = json_encode($reply_markup);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    curl_close($ch);
}

function editMessage($chat_id, $message_id, $text, $reply_markup = null) {
    global $bot_token;
    $url = "https://api.telegram.org/bot{$bot_token}/editMessageText";
    $data = [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) $data['reply_markup'] = json_encode($reply_markup);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    curl_close($ch);
}

function isValidChannel($input) {
    return preg_match('/^(@[a-zA-Z0-9_]{5,})|(https:\/\/t\.me\/[a-zA-Z0-9_]+)/', $input) || preg_match('/^-100[0-9]{10,}$/', $input);
}

function getMainKeyboard() {
    return [
        'inline_keyboard' => [
            [
                ['text' => '🚀 فوروارد خودکار', 'callback_data' => 'start_forward'],
                ['text' => '🤖 رباتساز', 'callback_data' => 'bot_creator']
            ]
        ]
    ];
}

if (!empty($text) && $text === '/start') {
    sendMessage($chat_id, "🎉 به ربات خوش اومدی! بیا با هم یه کار خفن راه بندازیم:", getMainKeyboard());
    $db->query("INSERT INTO forward_config (chat_id) VALUES ($chat_id)
        ON DUPLICATE KEY UPDATE state='idle'");
    exit;
}

if (!empty($callback_data)) {
    if ($callback_data === 'start_forward') {
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '📤 انتخاب کانال مبدا', 'callback_data' => 'set_source']],
                [['text' => '📥 انتخاب کانال مقصد', 'callback_data' => 'set_destination']],
                [['text' => '🔙 برگشت', 'callback_data' => 'back_home']]
            ]
        ];
        $text = "✨ آماده‌ای برای ساخت سیستم فوروارد خودکار؟\nیکی از گزینه‌های زیر رو انتخاب کن 👇";
        editMessage($callback_chat, $message_id, $text, $keyboard);
        exit;
    }
    if ($callback_data === 'bot_creator') {
        $keyboard = [
            'inline_keyboard' => [
                [['text' => '🔙 برگشت', 'callback_data' => 'back_home']]
            ]
        ];
        editMessage($callback_chat, $message_id, "🤖 خوش اومدی به بخش ساخت ربات! این بخش به زودی فعال می‌شه ✨", $keyboard);
        exit;
    }
    if ($callback_data === 'back_home') {
        editMessage($callback_chat, $message_id, "🎉 به ربات خوش اومدی! بیا با هم یه کار خفن راه بندازیم:", getMainKeyboard());
        exit;
    }
    if ($callback_data === 'set_source') {
        $db->query("UPDATE forward_config SET state='awaiting_source' WHERE chat_id=$callback_chat");
        sendMessage($callback_chat, "📤 لطفاً آی‌دی یا لینک کانال مبدا رو بفرست یا یک پست از اون فوروارد کن");
        exit;
    }
    if ($callback_data === 'set_destination') {
        $db->query("UPDATE forward_config SET state='awaiting_dest' WHERE chat_id=$callback_chat");
        sendMessage($callback_chat, "📥 لطفاً آی‌دی یا لینک کانال مقصد رو بفرست یا یک پست از اون فوروارد کن");
        exit;
    }
}

if (!empty($text) || !empty($forward_from_chat)) {
    $res = $db->query("SELECT * FROM forward_config WHERE chat_id=$chat_id");
    $conf = $res->fetch_assoc();
    $state = $conf['state'];
    $input = $forward_from_chat ?: trim($text);

    if (!$input || ($text && !isValidChannel($text))) {
        sendMessage($chat_id, "❌ فرمت لینک یا آی‌دی معتبر نیست. لطفاً مجدد امتحان کن 🙏");
        exit;
    }

    if ($state === 'awaiting_source') {
        $db->query("UPDATE forward_config SET from_channel='$input', state='idle' WHERE chat_id=$chat_id");
        sendMessage($chat_id, "✅ کانال مبدا با موفقیت ذخیره شد!");
    } elseif ($state === 'awaiting_dest') {
        $db->query("UPDATE forward_config SET to_channel='$input', state='idle' WHERE chat_id=$chat_id");
        sendMessage($chat_id, "✅ کانال مقصد با موفقیت ذخیره شد!");
    }

    $res = $db->query("SELECT from_channel, to_channel FROM forward_config WHERE chat_id=$chat_id");
    $row = $res->fetch_assoc();
    if (!empty($row['from_channel']) && !empty($row['to_channel'])) {
        $msg = "✅ کانال‌ها با موفقیت ثبت شدن!\n\n📤 مبدا: <code>{$row['from_channel']}</code>\n📥 مقصد: <code>{$row['to_channel']}</code>\n\n🎯 سیستم فوروارد آماده‌ست! هر پستی بیاد، منتقل میشه 🚀";
        sendMessage($chat_id, $msg);
    }
    exit;
}