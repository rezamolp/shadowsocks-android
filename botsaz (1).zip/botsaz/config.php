<?php
/* تنظیمات اتصال */
$telegram_token = '7779481446:AAEBRXmzDPWtCEVZn-kMIGY-PCG2rEamjAI';
$admin_id        = 6749624132;
$openai_api_key = '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';
$db_host        = 'localhost';
$db_name        = 'amargirparester_amar';
$db_user        = 'amargirparester_amar';
$db_pass        = 'gT3rF+.raHx=Tcu(';
?>