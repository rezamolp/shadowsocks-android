<?php
require __DIR__ . '/config.php';

$content = file_get_contents("php://input");
$update = json_decode($content, true);

$chat_id = $update['message']['chat']['id'] ?? null;
$text = $update['message']['text'] ?? null;

// این تابع برای ارسال پیام به کاربر استفاده می‌شود
function sendMessage($chat_id, $text) {
    global $bot_token;
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    curl_close($ch);
}

// دریافت توکن از کاربر
if ($text) {
    // چک کردن توکن
    if (preg_match('/^[0-9]+:[A-Za-z0-9_-]{35,}$/', $text)) {
        // ذخیره توکن و تنظیم وبهوک
        saveBotToken($chat_id, $text);
    } else {
        sendMessage($chat_id, "❌ توکن وارد شده معتبر نیست. لطفاً مجدداً تلاش کنید.");
    }
}

function saveBotToken($chat_id, $bot_token) {
    global $db;

    // ذخیره توکن در پایگاه داده
    $stmt = $db->prepare("INSERT INTO user_bots (owner_id, bot_token) VALUES (?, ?)");
    $stmt->bind_param("is", $chat_id, $bot_token);
    if ($stmt->execute()) {
        sendMessage($chat_id, "✅ ربات شما با موفقیت ایجاد شد!");
        $webhook_url = "https://amargir.parester.com/botsaz/bot.php";
        file_get_contents("https://api.telegram.org/bot{$bot_token}/setWebhook?url=" . urlencode($webhook_url)); // تنظیم وبهوک جدید
    } else {
        sendMessage($chat_id, "❌ خطا در ذخیره توکن. لطفاً دوباره تلاش کنید.");
    }
    $stmt->close();
}
?>
