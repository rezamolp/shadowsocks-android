<?php
require __DIR__ . '/config.php';

ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/install_error_log.txt');

// اتصال به پایگاه داده
function connectToDatabase() {
    global $db_host, $db_user, $db_pass, $db_name;
    try {
        $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
        if ($db->connect_error) {
            throw new Exception("[INSTALL] DB connection error: " . $db->connect_error);
        }
        $db->set_charset('utf8mb4');
        return $db;
    } catch (Exception $e) {
        error_log($e->getMessage());
        exit("❌ اتصال به پایگاه داده انجام نشد. لطفاً تنظیمات دیتابیس را بررسی کنید. پیام خطای دقیق: " . $e->getMessage());
    }
}

$db = connectToDatabase();

// ارسال دکمه «رباتساز»
function sendMessageWithBotBuilder($chat_id) {
    global $bot_token;
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    
    $reply_markup = [
        'inline_keyboard' => [
            [['text' => '🤖 رباتساز', 'callback_data' => 'create_bot']] // دکمه «رباتساز»
        ]
    ];

    $data = [
        'chat_id' => $chat_id,
        'text' => 'سلام! برای ساخت ربات شخصی خود، لطفاً دکمه زیر را فشار دهید.',
        'reply_markup' => json_encode($reply_markup)
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if (!$response || $http_code != 200) {
        error_log("[ERROR] Failed to send message to chat_id: {$chat_id}. HTTP Code: {$http_code}. Response: {$response}");
    }
}

// پاسخ‌دهی به درخواست‌های کاربر
function processCallbackQuery($callback_query) {
    global $bot_token;
    
    // اطمینان از وجود داده‌ها در callback_query
    if (!isset($callback_query['message']['chat']['id']) || !isset($callback_query['data'])) {
        error_log("[ERROR] Invalid callback query structure: " . json_encode($callback_query));
        return;
    }
    
    $chat_id = $callback_query['message']['chat']['id'];
    $callback_data = $callback_query['data'];

    if ($callback_data == 'create_bot') {
        sendMessageForBotToken($chat_id);
    }
}

// ارسال پیام درخواست توکن از کاربر
function sendMessageForBotToken($chat_id) {
    global $bot_token;
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    
    $data = [
        'chat_id' => $chat_id,
        'text' => '🎉 حالا توکن رباتت رو وارد کن تا ربات شخصی خودتو بسازی!'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $response = curl_exec($ch);
    curl_close($ch);
    
    if (!$response) {
        error_log("[ERROR] Failed to send token request to chat_id: {$chat_id}");
    }
}

// دریافت درخواست‌های کاربر
$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (isset($update['callback_query'])) {
    processCallbackQuery($update['callback_query']);
} elseif (isset($update['message'])) {
    $chat_id = $update['message']['chat']['id'];
    sendMessageWithBotBuilder($chat_id);
}

?>
