<?php
require __DIR__ . '/config.php';

$content = file_get_contents("php://input");
$update = json_decode($content, true);

$chat_id = $update['message']['chat']['id'] ?? null;
$text = $update['message']['text'] ?? null;

$db = new mysqli($db_host, $db_user, $db_pass, $db_name);
$db->set_charset('utf8mb4');

function sendMessage($chat_id, $text, $reply_markup = null) {
    $bot_token = getenv('CREATOR_BOT_TOKEN') ?: '7779481446:AAEBRXmzDPWtCEVZn-kMIGY-PCG2rEamjAI';
    $url = "https://api.telegram.org/bot{$bot_token}/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    if ($reply_markup) {
        $data['reply_markup'] = json_encode($reply_markup);
    }
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    curl_close($ch);
}

if (preg_match('/^[0-9]+:[A-Za-z0-9_-]{35,}$/', $text)) {
    $stmt = $db->prepare("INSERT INTO user_bots (owner_id, bot_token) VALUES (?, ?)");
    $stmt->bind_param("is", $chat_id, $text);
    if ($stmt->execute()) {
        $webhook_url = "https://amargir.parester.com/botsaz/bot.php";
        file_get_contents("https://api.telegram.org/bot{$text}/setWebhook?url=" . urlencode($webhook_url));
        sendMessage($chat_id, "✅ رباتت با موفقیت ساخته شد و به آخرین نسخه متصل شد!");
    } else {
        sendMessage($chat_id, "❌ خطا در ذخیره توکن. لطفاً دوباره تلاش کن.");
    }
    $stmt->close();
} else {
    sendMessage($chat_id, "❌ توکن معتبر نیست. لطفاً مجدد ارسال کن.");
    exit;
}